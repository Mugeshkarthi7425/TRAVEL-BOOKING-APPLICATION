from django.shortcuts import render, redirect
from django.contrib.auth import authenticate,login as auth_login
from django.contrib.auth.hashers import make_password, check_password
from django.contrib import messages
from django.contrib.auth.models import User
from datetime import date
from home.models import S_flight
from home.models import Flight_schedule,places,travel_passenger,payment_details
from datetime import datetime
from django.http import JsonResponse, HttpResponse
import json
from django.core.mail import send_mail
from django.contrib.auth import logout as auth_logout

def handlelogout(request):
    auth_logout(request)  # Log the user out
    return render(request, 'base.html')


#print(check_password('vdvyas@2307','pbkdf2_sha256$390000$bwUVr9rh4i7MEpPn8m9zgY$0eIwgc7TSJgWsWH4M85m2MCGAK023PtC1kJ8lVWNZwA='))
# Create your views here.
#global Depature,arrive,dept_date,return_date,travel_type,cabin_class

Depature=""
arrive=""
cabin_class=""
dept_date=""
return_date=""
twoway_dept_pnr_no=""
twoway_return_pnr_no=""
oneway_pnr_no=""
Travel_type=""
PNR_no=""
def home(request):
    #return HttpResponse("This is home page")
    return render(request,'base.html')

def service(request):
    return render(request,'services.html')

def booking(request):
    global Depature,cabin_class,arrive,dept_date,return_date,Travel_type
    if request.method=="POST":
       Travel_type=request.POST['checking']
       saverecord=S_flight()
       saverecord.travel_type=request.POST['checking']
       saverecord.depature=request.POST['From']
       Depature = request.POST['From'] 
       saverecord.arrive=request.POST['To']
       arrive=request.POST['To']
       arrive=request.POST['To']
       if Travel_type=="one-way":
           saverecord.return_date=date.today()
       else:
           saverecord.return_date=request.POST['returndate']
           return_date=request.POST['returndate']

       saverecord.depart_date=request.POST['departdate']
       dept_date=request.POST['departdate']
       print(dept_date)
       saverecord.no_of_passenger=request.POST['passenger']
       saverecord.cabin_class=request.POST['cabinclass']
       cabin_class=request.POST['cabinclass']
       saverecord.save()
       #print(travel_type)
       #print(depature)
       #print(arrive)
       if Travel_type=="return":
          print("redirect to return page")
          return redirect('/Return')
       else:
          print("redirect to one-way page")
          return redirect('/oneway')
    return render(request,'booking.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            auth_login(request, user)  # This logs the user in
            return redirect('home')  # Redirect to the home page (base.html)
        else:
            messages.error(request, 'Invalid username or password')

    return render(request, 'login.html')


def admin_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            if user.is_staff or user.is_superuser:  # Check if the user is an admin
                auth_login(request, user)  # This logs the admin in
                return redirect('admin_dashboard')  # Redirect to admin dashboard
            else:
                messages.error(request, 'You do not have admin privileges')
        else:
            messages.error(request, 'Invalid username or password')

    return render(request, 'admin_login.html')

# Home view to render base.html after login
def home(request):
    return render(request, 'base.html')



def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = User.objects.create_user(username=username, password=password)
        messages.success(request, 'Signup successful, please login.')
        return redirect('login')
    return render(request, 'register.html')
  

def Return(request):
    global Depature,cabin_class,arrive,dept_date,return_date,twoway_dept_pnr_no,twoway_return_pnr_no
    if request.method=="POST":
        twoway_dept_pnr_no = request.POST.get('dpnr')
        twoway_return_pnr_no= request.POST.get('rpnr')
        print("this is return")
        print(twoway_dept_pnr_no)
        print(twoway_return_pnr_no)

        return redirect('/ticketdetails')
    
    
    Flights_one=Flight_schedule.objects.filter(From__icontains=Depature).filter(To__icontains=arrive).filter(everyday__icontains="YES")
    Flights_two=Flight_schedule.objects.filter(From__icontains=arrive).filter(To__icontains=Depature).filter(everyday__icontains="YES")
    return render(request,'return.html', {'flights_one':Flights_one,'flights_two':Flights_two,'Cabin_class': cabin_class.upper() ,'from':Depature,'to': arrive,'Dept_date':dept_date,'Return_date':return_date})

def oneway(request):
     global Depature,cabin_class,arrive,dept_date,oneway_pnr_no
     if request.method=="POST":
        print("redirect to ticketdetails")
        oneway_pnr_no = request.POST.get('dpnr')
        print(oneway_pnr_no)

        return redirect('/ticketdetails')
    
     #depart_day = datetime.strptime(dept_date, "%Y-%m-%d")
     #depart_day=Week.objects.get(number=return_date.weekday())
     Flights=Flight_schedule.objects.filter(From__icontains=Depature).filter(To__icontains=arrive).filter(everyday__icontains="YES")
     return render(request,'oneway.html', {'flights':Flights,'Cabin_class': cabin_class.upper() ,'from':Depature,'to': arrive,'Dept_date':dept_date})

def adminpage(request):
     Flights=Flight_schedule.get_all_product()
     return render(request, 'adminpage.html', {'flights':Flights})

def addflight(request):
    if request.method=="POST":
        saverecord=Flight_schedule()
        saverecord.company_name=request.POST["company_name"]
        saverecord.From=request.POST["from"]
        saverecord.To=request.POST["to"]
        saverecord.pnr_no=request.POST["pnr_no"]
        saverecord.dept_time=request.POST["dept_time"]
        saverecord.rich_time=request.POST["rich_time"]
        saverecord.duration=request.POST["duration"]
        saverecord.economy_seat=request.POST["economy_seat"]
        saverecord.pre_economy_seat=request.POST["pre_economy_seat"]
        saverecord.business_seat=request.POST["business_seat"]
        saverecord.first_class_seat=request.POST["first_class_seat"]
        saverecord.economy_seat_price=request.POST["economy_seat_price"]
        saverecord.pre_economy_seat_price=request.POST["pre_economy_seat_price"]
        saverecord.business_price=request.POST["business_seat_price"]
        saverecord.first_class_seat_price=request.POST["first_class_seat_price"]
        saverecord.date=request.POST["date"]
        saverecord.everyday=request.POST["everyday"]
        print(saverecord.company_name)
        print(saverecord.dept_time)
        saverecord.save()
        return redirect('/addflight')
    return render (request,'addflight.html')

def ticketdetails(request):
    global cabin_class,Travel_type,twoway_dept_pnr_no,twoway_return_pnr_no,oneway_pnr_no
    if Travel_type=="return":
        print(twoway_dept_pnr_no)
        print(twoway_return_pnr_no)
        Flight_ticket_one=Flight_schedule.objects.filter(pnr_no__icontains=twoway_dept_pnr_no)
        Flight_ticket_two=Flight_schedule.objects.filter(pnr_no__icontains=twoway_return_pnr_no)
        zipped_segment= zip(Flight_ticket_one,Flight_ticket_two)
        return render(request,'ticketdetails.html',{'Cabin_class': cabin_class.upper(),'travel_type':Travel_type,'Zipped' : zipped_segment})
    else:
        Flight =Flight_schedule.objects.filter(pnr_no__icontains=oneway_pnr_no)
        print(oneway_pnr_no)
        print(Flight)
        return render(request,'ticketdetails.html',{'Cabin_class': cabin_class.upper(),'flights':Flight,'travel_type':Travel_type})
    
def savepassenger(request):
    if request.method == "POST": 
        #print(request.POST)
         vd =request.POST
         print("this is vd")
         print(vd)
         print(vd["First_name"])
         #print(request.POST[1])
         save_travel_passenger=travel_passenger()
         save_travel_passenger.First_name=vd["First_name"]
         save_travel_passenger.Last_name=vd["Last_name"]
         save_travel_passenger.Gender=vd["Gender"]
         save_travel_passenger.save()
         return JsonResponse({"message" : "request handle.."})
    
def payment(request):
    if request.method == "POST":
        saverecord = payment_details()
        saverecord.payment_amount = request.POST['payment-amount']
        saverecord.credit_card_number = request.POST['credit-card-number']
        saverecord.credit_holder_name = request.POST['credit-card-holder-name']
        
        month = request.POST['expiry-month']
        saverecord.month_year_expiry = datetime.strptime(month, '%Y-%m').date()
        
        saverecord.cvv_code = request.POST['cvv-code']
        saverecord.save()

        # Sending confirmation email
        send_mail(
            "Payment Confirmation",
            "Your payment has been successfully processed. Thank you for booking!",
            "flightbooking2307@gmail.com",
            ["vedantvyas2@gmail.com"],
            fail_silently=True,
        )

        # Redirect to the success page
        return redirect('payment_success')  # Redirect to the success view

    return render(request, 'payment.html')

def payment_success(request):
    return render(request, 'payment_success.html')

def payment_success(request):
    context = {
        'user_name': 'MUGESH KARTHI',  
        'payment_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),  
        'transaction_id': 'LA876NSU837UNA7'  
    }
    return render(request, 'payment_success.html', context)
